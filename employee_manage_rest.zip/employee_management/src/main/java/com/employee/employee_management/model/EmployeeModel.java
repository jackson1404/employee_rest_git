package com.employee.employee_management.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

public class EmployeeModel {
	
	@Getter
	@Setter
	private int employeeId;
	
	@Getter
	@Setter
	@NotBlank(message = "Name should not be blank")
	private String employeeName;
	
	@Getter
	@Setter
	@Min(value = 1, message = "Age must be greater than or equal to 1")
    @Max(value = 150, message = "Age must be less than or equal to 150")
	private int employeeAge;
	
	@Getter
	@Setter
	@NotBlank(message = "Address should not be blank")
	private String employeeAddress;
	
	
}
