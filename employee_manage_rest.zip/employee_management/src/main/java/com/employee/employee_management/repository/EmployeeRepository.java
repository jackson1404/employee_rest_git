package com.employee.employee_management.repository;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.stereotype.Repository;

import com.employee.employee_management.model.EmployeeModel;

@Repository
public interface EmployeeRepository {
	
	public int employeeDataAdd(EmployeeModel employeeModel);
	public List<EmployeeModel> selectAllData();
	public int deleteEmployee(int employeeId);
	public int updateProcess(@Param("employeeId")int employeeId,@Param("employeeModel")EmployeeModel employeeModel);
	public List<EmployeeModel> searchById(int employeeId);
	
}
