package com.employee.employee_management.service.serviceImpl;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.employee_management.model.AccountModel;
import com.employee.employee_management.model.EmployeeModel;
import com.employee.employee_management.repository.EmployeeRepository;
import com.employee.employee_management.repository.LoginRepository;
import com.employee.employee_management.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private LoginRepository loginRepository;
	
	@Override
	public int employeeDataAdd(EmployeeModel employeeModel) {	
		
		return employeeRepository.employeeDataAdd(employeeModel);
	}

	@Override
	public List<EmployeeModel> selectAllData() {
		
		return employeeRepository.selectAllData();
	}
	
	@Override
	public int deleteEmployee(int employeeId) {
		return employeeRepository.deleteEmployee(employeeId);
	}


	@Override
	public int updateProcess(@Param("employeeId")int employeeId,@Param("employeeModel")EmployeeModel employeeMdoel) {
		
		return employeeRepository.updateProcess(employeeId,employeeMdoel);
	}

	@Override
	public List<EmployeeModel> searchById(int employeeId) {
		return employeeRepository.searchById(employeeId);
	}

	@Override
	public int createAccount(AccountModel account) {
		
		return loginRepository.createAccount(account);
	}

	
}
