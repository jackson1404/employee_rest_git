package com.employee.employee_management.repository;

import org.springframework.stereotype.Repository;

import com.employee.employee_management.model.AccountModel;

@Repository
public interface LoginRepository {
	public AccountModel loginProcess(String username);
    public int createAccount(AccountModel account);
}
