package com.employee.employee_management.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.employee.employee_management.model.AccountModel;
import com.employee.employee_management.model.EmployeeModel;

public interface EmployeeService {
	
	public int employeeDataAdd(EmployeeModel employeeModel);
	public int deleteEmployee(int employeeId);
	public int updateProcess(@Param("employeeId")int employeeId, @Param("employeeModel") EmployeeModel employeeModel);
	public List<EmployeeModel> selectAllData();
	public List<EmployeeModel> searchById(int employeeId);
    public int createAccount(AccountModel account);

}
