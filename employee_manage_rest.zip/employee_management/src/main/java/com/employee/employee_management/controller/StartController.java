package com.employee.employee_management.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.*;

import com.employee.employee_management.model.AccountModel;
import com.employee.employee_management.model.EmployeeModel;
import com.employee.employee_management.repository.LoginRepository;
import com.employee.employee_management.service.serviceImpl.EmployeeServiceImpl;

import io.swagger.annotations.Api;

@Api(tags = "Employee Controller List")
@RestController
public class StartController {

    @Autowired
    private EmployeeServiceImpl employeeServiceImpl;
    
    @Autowired
    private LoginRepository loginRepository;

    @RequestMapping(value = {"/","/index"}, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<EmployeeModel> index() {
		return employeeServiceImpl.selectAllData();
	}
	
	@RequestMapping(value = {"/dataAdd"}, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> addEmployee(@Valid @RequestBody EmployeeModel employee, BindingResult bindResult) {
	    if (bindResult.hasErrors()) {
	        Map<String, Object> errorResponse = new HashMap<>();
	        errorResponse.put("status", HttpStatus.BAD_REQUEST.value());
	        errorResponse.put("message", "Validation error");
	        errorResponse.put("errors", getValidationErrors(bindResult));

	        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	    }

	    int result = employeeServiceImpl.employeeDataAdd(employee);

	    Map<String, Object> successResponse = new HashMap<>();
	    successResponse.put("status", HttpStatus.OK.value());
	    successResponse.put("message", "Employee added successfully");
	    successResponse.put("result", result);

	    return new ResponseEntity<>(successResponse, HttpStatus.OK);
	}

	private List<String> getValidationErrors(BindingResult bindResult) {
	    List<String> errors = new ArrayList<>();
	    
	    for (ObjectError error : bindResult.getAllErrors()) {
	        errors.add(error.getDefaultMessage());
	    }
	    return errors;
	}
	
	@DeleteMapping("/delete/{employeeId}")
    public ResponseEntity<String> deleteEmployee(@PathVariable("employeeId") int employeeId) {
        int result = employeeServiceImpl.deleteEmployee(employeeId);

        if (result > 0) {
            return new ResponseEntity<>("Employee deleted successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Employee not found", HttpStatus.NOT_FOUND);
        }
    }
	
	@RequestMapping(value = "/searchById/{employeeId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<EmployeeModel> searchById(@PathVariable("employeeId") int employeeId) {
		return employeeServiceImpl.searchById(employeeId);
	}

	@RequestMapping(value= {"/updateProcess/{employeeId}"}, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public int updateProcess(@PathVariable("employeeId") int employeeId,@RequestBody EmployeeModel employeeModel) {
        return employeeServiceImpl.updateProcess(employeeId, employeeModel);
    }
	
	 @PostMapping(value = {"/create"}, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseEntity<Object> createAccount(@RequestBody AccountModel account) {
		 	
		 	int userCteateResult = 0;
	
		 	account.setEnabled(true);
		 	account.setPassword(new BCryptPasswordEncoder().encode(account.getPassword()));
	        userCteateResult = loginRepository.createAccount(account);

	        if (userCteateResult > 0) {
	            return new ResponseEntity<>("Account created successfully", HttpStatus.OK);
	        } else {
	            return new ResponseEntity<>("Failed to create account", HttpStatus.BAD_REQUEST);
	        }
	    }
}
